import sys
if sys.version_info[0] != 3: 
	print("This script requires Python 3")
	exit()
